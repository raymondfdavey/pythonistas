from Room import Room

"""
    This class is the main class of the "Adventure World" application. 
    'Adventure World' is a very simple, text based adventure game. Users 
    can walk around some scenery. That's all. It should really be extended 
    to make it more interesting!
    
    To play this game, use the main() method in the AdventureWorldGUI class.

    This main class creates and initialises all the others: it creates all
    rooms, creates the parser and starts the game. It also evaluates and
    executes the commands that the parser returns.
    
    This game is adapted from the 'World of Zuul' by Michael Kolling
    and David J. Barnes. The original was written in Java and has been
    simplified and converted to Python by Kingsley Sage.
    
    This version adds the beginnings of a GUI using Tkinter.
"""

class Game:

    def __init__(self):
        """
        Initialises the game.
        """
        self.create_rooms()
        self.current_room = self.outside

    def create_rooms(self):
        """
            Sets up all room assets.
        :return: None
        """
        self.outside = Room("You are outside")
        self.lobby = Room("in the lobby")
        self.corridor = Room("in a corridor")
        self.lab = Room("in a computing lab")
        self.office = Room("in the computing admin office")
        self.HR_office = Room("full of elves doing work")
        self.hall_of_mirrors = Room("perfect for getting eaten by clowns")
        self.room_to_nowhere = Room("dead end dude")

        self.outside.set_exit("east", self.lobby)
        self.outside.set_exit("south", self.lab)
        self.outside.set_exit("west", self.corridor)
        self.lobby.set_exit("west", self.outside)
        self.corridor.set_exit("east", self.outside)
        self.lab.set_exit("north", self.outside)
        self.lab.set_exit("east", self.office)
        self.lab.set_exit("upstairs", self.HR_office)
        self.HR_office.set_exit("downstairs", self.lab)
        self.office.set_exit("west", self.lab)
        self.lobby.set_exit("southeast", self.hall_of_mirrors)
        self.hall_of_mirrors.set_exit("northwest", self.lobby)
        self.lab.set_exit("south", self.room_to_nowhere)

    def print_welcome(self):
        """
        Return the welcome message as a string.
        :return: string
        """
        self.msg = \
        f'You are lost. You are alone. You wander \n \
        around the deserted complex. \n\n \
        Your command words are: {self.show_command_words()}.'
        return self.msg

    def show_command_words(self):
        """
            Show a list of available commands.
        :return: list of commands as a string
        """
        return  'help, go'

    def print_help(self):
        """
            Display some useful help text.
        :return: message
        """
        msg = \
        f'You are lost. You are alone. You wander \n \
        around the deserted complex. \n\n \
        Your command words are: {self.show_command_words()}'
        return msg

    def do_go_command(self, second_word):
        """
            Performs the GO command.
        :param secondWord: the direction the player wishes to travel in
        :return: text output
        """
        if second_word == None:
            # Missing second word...
            return 'Go where?'

        next_room = self.current_room.get_exit(second_word)
        if next_room == None:
            return 'There is no door!'
        else:
            self.current_room = next_room
            return f'{self.current_room.get_long_description()}'
