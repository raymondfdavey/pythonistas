import tkinter as tk
from Game import Game

class App():

    # Creates a Frame for the application and populates the GUI...
    def __init__(self, root):

        self.game = Game()

        # Create two frames owned by the window root.
        # In order to use multiple layout managers, the frames
        # cannot share a parent frame. Here both frames are owned
        # by a top level instance root.

        self.frame1 = tk.Frame(root, width=400, height=150, bg='WHITE', borderwidth=2)
        self.frame1.pack_propagate(0)  # Prevents resizing
        self.frame2 = tk.Frame(root, width=400, height=150, bg='LIGHT GREY', borderwidth=2)
        self.frame2.grid_propagate(0)  # Prevents resizing
        # This packs both frames into the root window...
        self.frame1.pack()
        self.frame2.pack()

        # Now add some useful widgets...
        self.text_area1 = tk.Label(self.frame1, text='')
        self.text_area1.pack()
        self.cmd_area = tk.Entry(self.frame2, text='')
        self.cmd_area.pack()
        self.build_GUI()

    def build_GUI(self):
        self.cmd_button = tk.Button(self.frame2, text='Run command',
                                    fg='black', bg='blue',
                                    command=self.do_command)
        self.cmd_button.pack()
        self.text_area1.configure(text=self.game.print_welcome())

    def do_command(self):
        command = self.cmd_area.get()  # Returns a 2-tuple
        self.process_command(command)

    def get_command_string(self, input_line):
        """
            Fetches a command (borrowed from old TextUI).
        :return: a 2-tuple of the form (command_word, second_word)
        """
        word1 = None
        word2 = None
        if input_line != "":
            all_words = input_line.split()
            word1 = all_words[0]
            if len(all_words) > 1:
                word2 = all_words[1]
            else:
                word2 = None
            # Just ignore any other words
        return (word1, word2)

    def process_command(self, command):
        """
            Process a command.
        :param command: a 2-tuple of the form (command_word, second_word)
        """
        command_word, second_word = self.get_command_string(command)
        if command_word != None:
            command_word = command_word.upper()
            if command_word == "HELP":
                self.text_area1.configure(text=self.game.print_help())
            elif command_word == "GO":
                self.text_area1.configure(text=self.game.do_go_command(second_word))
            else:
                # Unknown command...
                self.text_area1.configure(text="Don't know what you mean.")

def main():
    win = tk.Tk()                           # Create a window
    win.title("Adventure World with GUI")   # Set window title
    win.geometry("400x300")                 # Set window size
    win.resizable(False, False)             # Both x and y dimensions...

    # Create the GUI as a Frame and attach it to the window...
    myApp = App(win)

    # Call the GUI mainloop...
    win.mainloop()

if __name__ == "__main__":
    main()
